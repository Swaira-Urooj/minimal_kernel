#![no_std] // Do not use the standard Library
#![no_main] // Do not use the main function.
#![feature(custom_test_frameworks)]
#![test_runner(crate::test_runner)]
mod vga_buffer;


use::core::panic::PanicInfo;    // Is a struct providing information for panics
//static HELLO: &[u8] = b"Welcome to the OS made by Haris, Uzair and Swaira";

#[cfg(test)]
pub fn test_runner(tests: &[&dyn Fn()]) {
    println!("Running {} tests", tests.len());
    for test in tests {
        test();
    }
}


#[unsafe(no_mangle)]    // Do not mangle the functions name
pub extern "C" fn _start() -> ! {
/*    use core::fmt::Write;
    vga_buffer::WRITER.lock().write_str("Hello AGAIN").unwrap();
    write!(vga_buffer::WRITER.lock(), ", some numbers: {} {}", 42, 0.33).unwrap();              */
    println!("Hello HHHHHHWorld{}", "!");
    println!("I Love Tokyo Ghoul");
    panic!("NO: ");
    //vga_buffer::print_something();
    //let vga_buffer = 0xb8000 as *mut u8;
    /* Linker will always look for a start function since it's the underlying compiler
     * for RUST. Thus we create a similar function that performs no significant operation for now
     * and just helps in linking and compiling
     * Named _start by default */
    
    loop{};
}

// Function for handling panics.
#[panic_handler] 
fn panic(info: &PanicInfo) -> ! {
    println!("{}", info);
    loop{};
}
